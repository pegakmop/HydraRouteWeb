const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { exec } = require('child_process');

const app = express();
const PORT = 2000;
const IPSET_FILE_PATH = '/opt/etc/AdGuardHome/ipset.conf';
const SERVICES_URL = "https://github.com/Ground-Zerro/DomainMapper/raw/refs/heads/main/platformdb";
const SCRIPT_FILE_PATHS = [
    '/opt/etc/ndm/ifstatechanged.d/010-bypass-table.sh',
    '/opt/etc/ndm/ifstatechanged.d/011-bypass6-table.sh',
    '/opt/etc/ndm/netfilter.d/010-bypass.sh',
    '/opt/etc/ndm/netfilter.d/011-bypass6.sh',
];

// Включаем CORS для всех маршрутов
app.use(cors());
app.use(express.static('/opt/etc/HydraRoute/public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});


////////////////// ipset.html //////////////////

// Функция для загрузки существующих доменов для маршрутов /load и /load-from-github
function loadExistingDomains() {
    if (fs.existsSync(IPSET_FILE_PATH)) {
        const data = fs.readFileSync(IPSET_FILE_PATH, 'utf8');
        return new Set(
            data.split(/\r?\n/)
                .map(line => line.split('/')[0].trim())
                .filter(Boolean)
        );
    }
    return new Set();
}

// Чтение и вывод существующих доменов
app.get('/load', (req, res) => {
    const existingDomains = Array.from(loadExistingDomains());
    res.send(existingDomains.join('\n'));
});

// Save ipset entries
app.post('/save', (req, res) => {
    const { ipset_content, protocols } = req.body;

    // Проверка на наличие данных
    if (!ipset_content) {
        return res.status(400).send('Нет данных для сохранения.');
    }

    // Определяем, использовать ли "bypass6"
    const ipv6Enabled = protocols && protocols.includes("IPv6");
    const suffix = ipv6Enabled ? "/bypass,bypass6" : "/bypass";

    // Функция очистки и обработки строк
    const sanitizeLine = (line) => {
        // Заменяем ":" и ";", а также пробелы на запятую
        let cleanedLine = line.replace(/[:;\s]+/g, ',');

        // Заменяем идущие подряд точки и запятые на единичный знак
        cleanedLine = cleanedLine.replace(/\.+/g, '.').replace(/,+/g, ',');

        // Удаляем символы, кроме букв, цифр, запятой, дефиса и точки
        cleanedLine = cleanedLine.replace(/[^\w\-,.]+/g, '');

        // Удаление спецсимволов и знаков препинания в конце строки
        cleanedLine = cleanedLine.replace(/[.,!?\/\\\- ]+$/, '');

        return cleanedLine;
    };

    // Разбиение текста на строки и обработка
    const lines = ipset_content.split(/\r?\n/).map(line => {
        const finalLine = sanitizeLine(line);

        // Добавление соответствующего суффикса к каждой строке
        return finalLine ? finalLine + suffix : null;
    }).filter(Boolean); // Убираем пустые строки

    const contentToWrite = lines.join('\n');

    // Сохранение в файл
    fs.writeFile(IPSET_FILE_PATH, contentToWrite, 'utf8', err => {
        if (err) {
            return res.status(500).send('Ошибка при сохранении.');
        }

        // Перезапуск AdGuard Home после успешного сохранения
        exec("/opt/etc/init.d/S99adguardhome restart", (error, stdout, stderr) => {
            if (error) {
                console.error(`Ошибка при перезапуске: ${error.message}`);
                return res.status(500).send('Ошибка при перезапуске AdGuardHome.');
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
            }
            res.send('Изменения успешно сохранены!');
        });
    });
});

// Загрузка списка сервисов и блэклистов с GitHub
app.get('/load-services', async (req, res) => {
    try {
        const response = await fetch(SERVICES_URL);
        const text = await response.text();
        const lines = text.split(/\r?\n/).filter(Boolean);
        const services = lines.map(line => {
            // Ищем индекс последовательности ": "
            const separatorIndex = line.indexOf(': ');
            if (separatorIndex !== -1) {
                const name = line.substring(0, separatorIndex).trim();
                const url = line.substring(separatorIndex + 2).trim(); // +2 чтобы пропустить ": "
                return { name, url };
            }
            return null; // если разделителя нет, то пропускаем эту строку
        }).filter(service => service !== null); // Убираем пустые значения

        res.json(services);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка загрузки списка сервисов.' });
    }
});


// Загрузка и фильтрация доменных имен из сервисов GitHub
app.post('/load-from-github', async (req, res) => {
    const { services } = req.body;

    if (!services || !services.length) {
        return res.status(400).send('Нет выбранных сервисов для загрузки.');
    }

    try {
        const allDomains = new Set();

        // Вспомогательная функция для удаления BOM из текста
        const removeBOM = (content) => {
            return content.startsWith('\uFEFF') ? content.slice(1) : content;
        };

        // Вспомогательная функция для извлечения корневого домена
        const getRootDomain = (domain) => {
            const parts = domain.split('.');
            return parts.length > 2 ? parts.slice(-2).join('.') : domain;
        };

        // Вспомогательная функция для консолидации доменов по корневым
        const consolidateDomains = (domains) => {
            const rootMap = new Map();
            
            domains.forEach(domain => {
                const rootDomain = getRootDomain(domain);
                if (!rootMap.has(rootDomain)) {
                    rootMap.set(rootDomain, new Set());
                }
                rootMap.get(rootDomain).add(domain);
            });

            return Array.from(rootMap.entries()).map(([root, subs]) =>
                subs.size > 1 ? root : Array.from(subs)[0]
            );
        };

        // Загружаем и объединяем домены из всех сервисов
        for (const serviceUrl of services) {
            const response = await fetch(serviceUrl);
            let content = await response.text();
            content = removeBOM(content);
            content.split(/\r?\n/)
                   .map(line => line.trim())
                   .filter(Boolean)
                   .forEach(domain => allDomains.add(domain));
        }

        const consolidatedDomains = consolidateDomains(Array.from(allDomains));
        const existingDomains = new Set(
            Array.from(loadExistingDomains())
                .flatMap(domain => domain.split(','))
                .map(domain => domain.trim())
                .filter(Boolean)
        );
        const newDomains = consolidatedDomains.filter(domain => !existingDomains.has(domain));

        if (newDomains.length > 0) {
            fs.appendFileSync(IPSET_FILE_PATH, '\n' + newDomains.join(',') + '/bypass');
        }

        res.send('Сервисы добавлены, не забудьте сохранить изменения.');
    } catch (error) {
        res.status(500).send('Ошибка обработки сервисов.');
    }
});


////////////////// settings.html //////////////////

// Получение текущего VPN-интерфейса
app.get('/vpn-interface', (req, res) => {
    try {
        const data = fs.readFileSync(SCRIPT_FILE_PATHS[0], 'utf8'); // Читаем первый файл
        const match = data.match(/\[\s*"\$system_name"\s*==\s*"(.+?)"\s*\]/);
        const vpnInterface = match ? match[1] : 'Не найдено';
        res.json({ vpnInterface });
    } catch (error) {
        res.json({ vpnInterface: 'Ошибка' });
    }
});

// Получение списка сетевых интерфейсов
app.get('/network-interfaces', (req, res) => {
    const interfaces = os.networkInterfaces();
    const result = [];

    for (const [name, addresses] of Object.entries(interfaces)) {
        const ipv4 = addresses.filter(addr => addr.family === 'IPv4' && !addr.internal && addr.address !== '127.0.0.1').map(addr => addr.address);
        const ipv6 = addresses.filter(addr => addr.family === 'IPv6' && !addr.internal && addr.address !== '::1').map(addr => addr.address);

        if (ipv4.length > 0 || ipv6.length > 0) {
            result.push({ name, ipv4: ipv4.join(', '), ipv6: ipv6.join(', ') });
        }
    }

    res.json(result);
});

// Сохранение нового VPN-интерфейса в нескольких файлах
app.post('/vpn-interface-save', (req, res) => {
    const { currentVpnInterface, newVpnInterface } = req.body;

    if (!newVpnInterface) {
        return res.status(400).json({ message: 'Ошибка: интерфейс не указан.' });
    }

    let successCount = 0;

    // Функция для поиска и замены интерфейса в файле
    function replaceInterfaceInFile(filePath) {
        try {
            let data = fs.readFileSync(filePath, 'utf8');

            if (!data.includes(currentVpnInterface)) {
                return false;
            }

            // Прямая замена без изменения других частей файла
            const updatedData = data.replace(new RegExp(`\\b${currentVpnInterface}\\b`, 'g'), newVpnInterface);

            fs.writeFileSync(filePath, updatedData, 'utf8');
            return true;
        } catch (error) {
            return false;
        }
    }

    SCRIPT_FILE_PATHS.forEach(filePath => {
        if (replaceInterfaceInFile(filePath)) {
            successCount++;
        }
    });

    if (successCount > 0) {
        res.json({ message: `Установлен интерфейс: ${newVpnInterface}` });
    } else {
        res.status(500).json({ message: 'Ошибка: не удалось обновить интерфейс.' });
    }
});


////////////////// adguard.html //////////////////

// Получение IP-адреса br0
app.get('/br0ip', (req, res) => {
    res.json({ ip: br0IP });
});

// Статус AdGuardHome
app.get('/agh-status', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome status", (error, stdout, stderr) => {
        if (error) {
            return res.status(500).send('Не удалось получить статус...');
        }

        const status = stdout.includes("alive") ? "Запущен и работает" : "Остановлен";
        res.send(status);
    });
});

// Перезапуск AdGuardHome
app.post('/agh-restart', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome restart", (error, stdout, stderr) => {
        if (error) {
            return res.status(500).send('Перезапуск не удался...');
        }

        res.send('Ok');
    });
});


////////////////// web server //////////////////

//запуск web
function getBr0IP() {
    const interfaces = os.networkInterfaces();
    if (interfaces.br0) {
        const br0 = interfaces.br0.find(addr => addr.family === 'IPv4' && !addr.internal);
        return br0 ? br0.address : null;
    }
    return null;
}

const br0IP = getBr0IP();
if (!br0IP) {
    console.error("Не удалось определить IP-адрес интерфейса br0.");
    process.exit(1);
}

app.listen(PORT, br0IP, () => {
    console.log(`Сервер запущен на http://${br0IP}:${PORT}`);
});

